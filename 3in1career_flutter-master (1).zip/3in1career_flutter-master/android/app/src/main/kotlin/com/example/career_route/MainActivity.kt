package com.example.career_route

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
